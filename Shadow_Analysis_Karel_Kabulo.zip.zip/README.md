# Shadow Analysis API (FastAPI + MongoDB)

## 1) Setup (local)
```bash
cd shadow-app
python -m venv .venv
.\.venv\Scripts\Activate
pip install -r requirements.txt
